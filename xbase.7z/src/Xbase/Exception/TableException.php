<?php 

namespace ShpAdapter\XBase\Exception;

class TableException extends \RuntimeException
{
}