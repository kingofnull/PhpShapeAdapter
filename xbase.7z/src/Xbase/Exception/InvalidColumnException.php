<?php 

namespace ShpAdapter\XBase\Exception;

class InvalidColumnException extends \InvalidArgumentException
{
}