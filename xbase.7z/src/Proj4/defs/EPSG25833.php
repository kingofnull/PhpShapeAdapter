<?php

return [
    "EPSG:25833" => "+proj=utm +zone=33 +ellps=GRS80 +units=m +no_defs",
];
